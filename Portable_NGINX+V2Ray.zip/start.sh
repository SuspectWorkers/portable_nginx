#!/bin/bash

chmod +x xray
chmod +x nginx
./nginx -c some.conf -e error.log -p . &
./xray run -c xray.json