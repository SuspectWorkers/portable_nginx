#!/bin/bash

chmod +x node_web
chmod +x node_vr
./node_web -c some.conf -e error.log -p . &
./node_vr run -c c.json